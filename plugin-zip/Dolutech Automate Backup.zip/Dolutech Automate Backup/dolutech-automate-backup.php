<?php
/*
Plugin Name: Dolutech Automate Backup
Description: Realiza backup completo do ambiente WordPress, permitindo backups locais ou envio para um servidor FTP, com logs detalhados e opções de configuração. Agora com opção de restauração de backups.
Version: 0.1.0
Author: Lucas Catão de Moraes
Author URI: https://dolutech.com
License: GPL-2.0+
License URI: http://www.gnu.org/licenses/gpl-2.0.txt
Text Domain: dolutech-automate-backup
Requires PHP: 7.4
Requires at least: 6.5
*/

if (!defined('ABSPATH')) exit;

// Verificar requisitos mínimos de versão do PHP e WordPress
if (version_compare(PHP_VERSION, '7.4', '<') || version_compare(get_bloginfo('version'), '6.5', '<')) {
    add_action('admin_notices', function() {
        echo '<div class="error"><p><strong>Dolutech Automate Backup:</strong> Requer o PHP 7.4 ou superior e WordPress 6.5 ou superior.</p></div>';
    });
    return;
}

class Dolutech_Automate_Backup {

    private $plugin_dir;
    private $backup_dir;

    public function __construct() {
        $this->plugin_dir = plugin_dir_path(__FILE__);
        $this->backup_dir = $this->plugin_dir . 'backups';

        // Cria o diretório de backups ao ativar o plugin
        register_activation_hook(__FILE__, [$this, 'create_backup_directory']);

        add_action('admin_menu', [$this, 'create_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('admin_post_save_backup_settings', [$this, 'save_backup_settings']);
        add_action('admin_post_manual_backup', [$this, 'manual_backup']);
        add_action('admin_post_download_backup', [$this, 'download_backup']);
        add_action('admin_post_delete_backup', [$this, 'delete_backup']);
        add_action('admin_post_clear_log', [$this, 'clear_log']);
        add_action('admin_post_restore_backup', [$this, 'restore_backup']);
        add_action('admin_post_upload_restore_backup', [$this, 'upload_restore_backup']);
        add_action('wp_ajax_get_backup_progress', [$this, 'get_backup_progress']);
        add_action('wp_ajax_get_restore_progress', [$this, 'get_restore_progress']);

        // Ação para o evento agendado do backup em segundo plano
        add_action('dolutech_background_backup', [$this, 'create_backup']);
        add_action('dolutech_background_restore', [$this, 'perform_restore']);

        if (get_option('automatic_backup_enabled') === 'on') {
            add_action('auto_backup_event', [$this, 'create_backup']);
            $this->schedule_cron_jobs();
        }

        // Registro de intervalos adicionais de agendamento
        add_filter('cron_schedules', [$this, 'custom_cron_schedules']);

        // Registro de ações AJAX
        add_action('wp_ajax_manual_backup', [$this, 'manual_backup']);
        add_action('wp_ajax_restore_backup', [$this, 'restore_backup']);
    }

    // Cria o diretório de backups com permissões corretas
    public function create_backup_directory() {
        if (!file_exists($this->backup_dir)) {
            if (!mkdir($this->backup_dir, 0755, true)) {
                error_log("Falha ao criar o diretório de backups em {$this->backup_dir}");
            }
        } else {
            // Verifica se o diretório é gravável
            if (!is_writable($this->backup_dir)) {
                if (!chmod($this->backup_dir, 0755)) {
                    error_log("Falha ao definir permissões no diretório de backups em {$this->backup_dir}");
                }
            }
        }
    }

    public function enqueue_scripts($hook) {
        if ($hook !== 'toplevel_page_dolutech-automate-backup') {
            return;
        }
        wp_enqueue_style('dolutech_backup_styles', plugin_dir_url(__FILE__) . 'style.css');
        wp_enqueue_script('dolutech_backup_script', plugin_dir_url(__FILE__) . 'script.js', ['jquery'], null, true);
        wp_localize_script('dolutech_backup_script', 'dolutechBackup', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('dolutech_backup_nonce_action')
        ]);
    }

    public function create_admin_menu() {
        add_menu_page(
            'Dolutech Automate Backup',
            'Dolutech Backup',
            'manage_options',
            'dolutech-automate-backup',
            [$this, 'settings_page'],
            'dashicons-backup',
            80
        );
    }

    public function settings_page() {
        $backups = glob($this->backup_dir . '/*.zip');
        ?>
        <div class="dolutech-backup-wrap">
            <div class="dolutech-header">
                <img src="<?php echo plugin_dir_url(__FILE__) . 'Dolutech-Automate-Backup-logo.png'; ?>" alt="Dolutech Automate Backup Logo" class="dolutech-logo">
                <h1>Dolutech Automate Backup</h1>
                <p class="dolutech-subtitle">Faça backup completo do seu ambiente WordPress de maneira prática e segura.</p>
            </div>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="dolutech-form">
                <input type="hidden" name="action" value="save_backup_settings">
                <?php wp_nonce_field('dolutech_backup_nonce_action', 'dolutech_backup_nonce'); ?>

                <h2 class="dolutech-section-title">Configurações de Backup</h2>
                <div class="dolutech-section">
                    <label for="backup_type">Tipo de Backup</label>
                    <select name="backup_type" id="backup_type">
                        <option value="local" <?php selected(get_option('backup_type'), 'local'); ?>>Backup Local</option>
                        <option value="ftp" <?php selected(get_option('backup_type'), 'ftp'); ?>>Enviar para Servidor FTP</option>
                    </select>
                </div>

                <h2 class="dolutech-section-title">Configurações de FTP</h2>
                <div class="dolutech-section">
                    <label for="ftp_host">Servidor FTP</label>
                    <input type="text" name="ftp_host" id="ftp_host" value="<?php echo esc_attr(get_option('ftp_host')); ?>" class="regular-text">

                    <label for="ftp_user">Usuário FTP</label>
                    <input type="text" name="ftp_user" id="ftp_user" value="<?php echo esc_attr(get_option('ftp_user')); ?>" class="regular-text">

                    <label for="ftp_pass">Senha FTP</label>
                    <input type="password" name="ftp_pass" id="ftp_pass" value="<?php echo esc_attr(get_option('ftp_pass')); ?>" class="regular-text">

                    <label for="ftp_secure">FTP Seguro (FTPS)</label>
                    <input type="checkbox" name="ftp_secure" id="ftp_secure" <?php checked(get_option('ftp_secure'), 'on'); ?>>

                    <label for="ftp_backup_path">Caminho do Backup no Servidor FTP</label>
                    <input type="text" name="ftp_backup_path" id="ftp_backup_path" value="<?php echo esc_attr(get_option('ftp_backup_path')); ?>" class="regular-text">
                </div>

                <h2 class="dolutech-section-title">Configurações de Backup Automático</h2>
                <div class="dolutech-section">
                    <label for="automatic_backup_enabled">Ativar Backup Automático</label>
                    <input type="checkbox" name="automatic_backup_enabled" id="automatic_backup_enabled" <?php checked(get_option('automatic_backup_enabled'), 'on'); ?>>
                </div>

                <h2 class="dolutech-section-title">Agendamento de Backup</h2>
                <div class="dolutech-section">
                    <label for="backup_schedule">Frequência do Backup</label>
                    <select name="backup_schedule" id="backup_schedule">
                        <option value="daily" <?php selected(get_option('backup_schedule'), 'daily'); ?>>Diário</option>
                        <option value="weekly" <?php selected(get_option('backup_schedule'), 'weekly'); ?>>Semanal</option>
                        <option value="biweekly" <?php selected(get_option('backup_schedule'), 'biweekly'); ?>>Quinzenal</option>
                        <option value="monthly" <?php selected(get_option('backup_schedule'), 'monthly'); ?>>Mensal</option>
                    </select>

                    <label for="backup_time">Hora do Backup</label>
                    <input type="time" name="backup_time" id="backup_time" value="<?php echo esc_attr(get_option('backup_time', '02:00')); ?>">
                </div>

                <h2 class="dolutech-section-title">Configurações de Notificação</h2>
                <div class="dolutech-section">
                    <label for="notification_email">E-mail de Notificação</label>
                    <input type="email" name="notification_email" id="notification_email" value="<?php echo esc_attr(get_option('notification_email')); ?>" class="regular-text">
                </div>

                <p class="submit"><input type="submit" class="button-primary" value="Salvar Configurações"></p>
            </form>

            <!-- Botão de Backup Manual -->
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="manual_backup">
                <?php wp_nonce_field('dolutech_backup_nonce_action', 'dolutech_backup_nonce'); ?>
                <p><input type="submit" class="button-secondary" id="backup-button" value="Fazer Backup Manual"></p>
            </form>

            <div id="backup-progress-bar">
                <div class="progress"></div>
            </div>

            <h2 class="dolutech-section-title">Backups Locais Disponíveis</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Nome do Arquivo</th>
                        <th>Data de Criação</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($backups): ?>
                        <?php foreach ($backups as $backup): ?>
                            <tr>
                                <td><?php echo esc_html(basename($backup)); ?></td>
                                <td><?php echo esc_html(date('d/m/Y H:i:s', filemtime($backup))); ?></td>
                                <td>
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline;">
                                        <input type="hidden" name="action" value="download_backup">
                                        <input type="hidden" name="backup_file" value="<?php echo esc_attr(basename($backup)); ?>">
                                        <?php wp_nonce_field('dolutech_backup_nonce_action', 'dolutech_backup_nonce'); ?>
                                        <input type="submit" class="button" value="Download">
                                    </form>
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline;">
                                        <input type="hidden" name="action" value="delete_backup">
                                        <input type="hidden" name="backup_file" value="<?php echo esc_attr(basename($backup)); ?>">
                                        <?php wp_nonce_field('dolutech_backup_nonce_action', 'dolutech_backup_nonce'); ?>
                                        <input type="submit" class="button" value="Excluir" onclick="return confirm('Tem certeza que deseja excluir este backup?');">
                                    </form>
                                    <!-- Botão de Restauração -->
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline;">
                                        <input type="hidden" name="action" value="restore_backup">
                                        <input type="hidden" name="backup_file" value="<?php echo esc_attr(basename($backup)); ?>">
                                        <?php wp_nonce_field('dolutech_backup_nonce_action', 'dolutech_backup_nonce'); ?>
                                        <input type="hidden" name="confirm_restore" value="yes">
                                        <input type="submit" class="button" value="Restaurar" onclick="return confirm('A restauração irá sobrescrever seus arquivos e banco de dados atuais. Deseja continuar?');">
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="3">Nenhum backup disponível.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <h2 class="dolutech-section-title">Restaurar Backup por Upload</h2>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data">
                <input type="hidden" name="action" value="upload_restore_backup">
                <?php wp_nonce_field('dolutech_backup_nonce_action', 'dolutech_backup_nonce'); ?>
                <label for="backup_file_upload">Selecione o arquivo de backup (.zip):</label>
                <input type="file" name="backup_file_upload" id="backup_file_upload" accept=".zip" required>
                <p><input type="submit" class="button" value="Restaurar Backup" onclick="return confirm('A restauração irá sobrescrever seus arquivos e banco de dados atuais. Deseja continuar?');"></p>
            </form>

            <h2 class="dolutech-section-title">Log de Backup</h2>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="clear_log">
                <?php wp_nonce_field('dolutech_backup_nonce_action', 'dolutech_backup_nonce'); ?>
                <p><input type="submit" class="button" value="Limpar Log"></p>
            </form>
            <pre class="dolutech-log"><?php echo esc_html(get_option('backup_log')); ?></pre>

            <!-- Rodapé com Créditos e Mensagem de Doação -->
            <div class="dolutech-footer" style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ccc; text-align: center;">
                <p>
                    Desenvolvido por: <a href="https://dolutech.com" target="_blank" rel="noopener noreferrer">Lucas Catão de Moraes</a>
                </p>
                <p>
                    Se você gosta do plugin, considere me pagar um café: <a href="https://www.paypal.com/paypalme/cataodemoraes" target="_blank" rel="noopener noreferrer">Clique aqui para doar</a>
                </p>
            </div>
        </div>
        <?php
    }

    public function get_backup_progress() {
        check_ajax_referer('dolutech_backup_nonce_action', 'nonce');
        $progress = get_option('backup_progress', 0);
        wp_send_json_success(['progress' => $progress]);
    }

    public function get_restore_progress() {
        check_ajax_referer('dolutech_backup_nonce_action', 'nonce');
        $progress = get_option('restore_progress', 0);
        wp_send_json_success(['progress' => $progress]);
    }

    private function set_backup_progress($progress) {
        update_option('backup_progress', $progress);
    }

    private function set_restore_progress($progress) {
        update_option('restore_progress', $progress);
    }

    public function manual_backup() {
        if (!current_user_can('manage_options')) {
            wp_die('Permissão insuficiente.');
        }

        // Verifica o nonce
        if (isset($_POST['nonce'])) {
            check_ajax_referer('dolutech_backup_nonce_action', 'nonce');
        } else {
            wp_die('Nonce não fornecido.');
        }

        // Iniciar o backup em segundo plano
        $this->set_backup_progress(0);
        wp_schedule_single_event(time(), 'dolutech_background_backup');

        // Enviar e-mail informando que o backup foi iniciado
        $backup_type = get_option('backup_type', 'local');
        $backup_type_label = ($backup_type === 'ftp') ? 'via FTP' : 'localmente';
        $this->send_email_notification("Backup iniciado.", 'success', $backup_type);

        // Retornar resposta JSON para AJAX
        wp_send_json_success(['message' => 'Backup iniciado. Acompanhe o progresso abaixo.']);
    }

    public function create_backup() {
        // Definir o diretório temporário
        putenv('TMPDIR=' . $this->backup_dir);

        $site_name = sanitize_title(get_bloginfo('name'));
        $backup_file_name = $site_name . '-' . date('Y-m-d-H-i-s') . '.zip';
        $zip_file = $this->backup_dir . '/' . $backup_file_name;

        $this->log_message("Iniciando backup...");

        // Inclui o PclZip
        if (!class_exists('PclZip')) {
            require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';
        }

        // Faz o backup do banco de dados
        $db_backup_file = $this->backup_dir . '/database-' . date('Y-m-d-H-i-s') . '.sql';

        $this->log_message("Fazendo backup do banco de dados...");
        if (!$this->backup_database($db_backup_file)) {
            $this->log_message("Erro ao fazer o backup do banco de dados.", 'ERROR');
            $this->send_email_notification("Erro ao fazer o backup do banco de dados.", 'error');
            return;
        }
        $this->log_message("Backup do banco de dados concluído.");

        $this->log_message("Compactando arquivos do WordPress...");
        $this->set_backup_progress(10);

        // Cria uma nova instância do PclZip
        $archive = new PclZip($zip_file);

        // Lista de arquivos para incluir no backup
        $files_to_backup = ABSPATH;

        // Adiciona os arquivos do WordPress ao backup
        $v_list = $archive->create($files_to_backup, PCLZIP_OPT_REMOVE_PATH, ABSPATH);

        // Verifica se a criação do arquivo ZIP foi bem-sucedida
        if ($v_list == 0) {
            $this->log_message("Erro ao criar o arquivo ZIP: " . $archive->errorInfo(true), 'ERROR');
            $this->send_email_notification("Erro ao criar o arquivo ZIP: " . $archive->errorInfo(true), 'error');
            return;
        }

        // *** Correção Aqui: Adiciona o arquivo .sql diretamente na raiz da pasta 'database' dentro do ZIP ***
        // Utilizamos PCLZIP_OPT_REMOVE_PATH para remover o caminho absoluto e PCLZIP_OPT_ADD_PATH para definir 'database' como o caminho dentro do ZIP
        $archive->add($db_backup_file, PCLZIP_OPT_REMOVE_PATH, $this->backup_dir, PCLZIP_OPT_ADD_PATH, 'database');

        // Remove o arquivo SQL temporário
        if (file_exists($db_backup_file)) {
            unlink($db_backup_file);
            $this->log_message("Arquivo de backup do banco de dados removido após compactação.");
        }

        $this->set_backup_progress(70);

        // Verifica se o arquivo ZIP foi realmente criado
        if (!file_exists($zip_file)) {
            $this->log_message("Erro: O arquivo de backup ZIP não foi criado.", 'ERROR');
            $this->send_email_notification("Erro: O arquivo de backup ZIP não foi criado.", 'error');
            return;
        }

        // Verifica se o backup é local ou para enviar ao FTP
        $backup_type = get_option('backup_type', 'local');

        if ($backup_type === 'ftp') {
            $this->log_message("Enviando backup para o servidor FTP...");
            $ftp_success = $this->upload_to_ftp($zip_file);

            if ($ftp_success) {
                $this->log_message("Backup enviado com sucesso para o FTP.");
                // Remove o backup local após o envio
                if (unlink($zip_file)) {
                    $this->log_message("Backup local removido após envio para o FTP.");
                } else {
                    $this->log_message("Erro ao remover o backup local após envio para o FTP.", 'ERROR');
                }
                $this->send_email_notification("Backup concluído com sucesso via FTP.", 'success', 'ftp');
            } else {
                $this->log_message("Erro ao enviar o backup para o FTP.", 'ERROR');
                $this->send_email_notification("Erro ao enviar o backup para o FTP.", 'error');
            }
        } else {
            $this->log_message("Backup salvo localmente em {$zip_file}.");
            $this->send_email_notification("Backup concluído com sucesso localmente.", 'success', 'local');
        }

        $this->set_backup_progress(100);
        $this->log_message("Backup concluído.");
    }

    // Função de backup do banco de dados atualizada
    private function backup_database($file) {
        global $wpdb;

        $sql = '';

        // Obter todas as tabelas do banco de dados
        $tables = $wpdb->get_col('SHOW TABLES');

        foreach ($tables as $table) {
            // Obter a instrução de criação da tabela
            $create_table = $wpdb->get_row("SHOW CREATE TABLE `$table`", ARRAY_N);
            if (isset($create_table[1])) {
                $sql .= $create_table[1] . ";\n\n";
            }

            // Obter os dados da tabela
            $rows = $wpdb->get_results("SELECT * FROM `$table`", ARRAY_A);

            foreach ($rows as $row) {
                $escaped_values = array_map(function($value) {
                    if ($value === null) {
                        return 'NULL';
                    } else {
                        return "'" . addslashes($value) . "'";
                    }
                }, $row);

                $sql .= "INSERT INTO `$table` (`" . implode("`, `", array_keys($row)) . "`) VALUES (" . implode(", ", $escaped_values) . ");\n";
            }
            $sql .= "\n\n";
        }

        // Salvar o conteúdo SQL no arquivo
        if (file_put_contents($file, $sql) === false) {
            $this->log_message("Erro ao escrever o arquivo de backup do banco de dados em $file.", 'ERROR');
            return false;
        }

        return true;
    }

    private function upload_to_ftp($file) {
        $ftp_host = sanitize_text_field(get_option('ftp_host'));
        $ftp_user = sanitize_text_field(get_option('ftp_user'));
        $ftp_pass = sanitize_text_field(get_option('ftp_pass'));
        $ftp_secure = get_option('ftp_secure') === 'on';
        $ftp_backup_path = sanitize_text_field(get_option('ftp_backup_path'));
        $ftp_backup_path = rtrim($ftp_backup_path, '/');

        $this->log_message("Conectando ao servidor FTP...");

        // Suprime avisos de conexão
        $conn_id = $ftp_secure ? @ftp_ssl_connect($ftp_host) : @ftp_connect($ftp_host);

        if (!$conn_id) {
            $this->log_message("Erro: Não foi possível conectar ao servidor FTP ({$ftp_host}).", 'ERROR');
            return false;
        }

        // Suprime avisos de login
        $login_result = @ftp_login($conn_id, $ftp_user, $ftp_pass);

        if (!$login_result) {
            $this->log_message("Erro: Falha na autenticação FTP para o usuário {$ftp_user}.", 'ERROR');
            @ftp_close($conn_id);
            return false;
        }

        ftp_pasv($conn_id, true);

        if ($ftp_backup_path) {
            // Certifique-se de que o caminho de backup está sempre dentro da pasta de backups
            $ftp_backup_path = ltrim($ftp_backup_path, '/'); // Remove a barra inicial, se existir

            if (!@ftp_chdir($conn_id, $ftp_backup_path)) {
                if (!@ftp_mkdir($conn_id, $ftp_backup_path)) {
                    $this->log_message("Erro: Não foi possível acessar ou criar o diretório {$ftp_backup_path} no FTP.", 'ERROR');
                    @ftp_close($conn_id);
                    return false;
                }
                ftp_chdir($conn_id, $ftp_backup_path);
            }
        }

        $this->log_message("Enviando arquivo para o FTP...");
        $upload = @ftp_put($conn_id, basename($file), $file, FTP_BINARY);

        @ftp_close($conn_id);

        if (!$upload) {
            $this->log_message("Erro: Falha ao enviar o arquivo para o FTP.", 'ERROR');
            return false;
        }

        return true;
    }

    public function save_backup_settings() {
        if (!current_user_can('manage_options')) {
            wp_die('Permissão insuficiente.');
        }

        check_admin_referer('dolutech_backup_nonce_action', 'dolutech_backup_nonce');

        // Sanitização das entradas
        $backup_type = sanitize_text_field($_POST['backup_type']);
        $ftp_host = sanitize_text_field($_POST['ftp_host']);
        $ftp_user = sanitize_text_field($_POST['ftp_user']);
        $ftp_pass = sanitize_text_field($_POST['ftp_pass']);
        $ftp_secure = isset($_POST['ftp_secure']) ? 'on' : 'off';
        $ftp_backup_path = sanitize_text_field($_POST['ftp_backup_path']);
        $automatic_backup_enabled = isset($_POST['automatic_backup_enabled']) ? 'on' : 'off';
        $backup_schedule = sanitize_text_field($_POST['backup_schedule']);
        $backup_time = sanitize_text_field($_POST['backup_time']);
        $notification_email = sanitize_email($_POST['notification_email']);

        // Atualização das opções
        update_option('backup_type', $backup_type);
        update_option('ftp_host', $ftp_host);
        update_option('ftp_user', $ftp_user);
        update_option('ftp_pass', $ftp_pass);
        update_option('ftp_secure', $ftp_secure);
        update_option('ftp_backup_path', $ftp_backup_path);
        update_option('automatic_backup_enabled', $automatic_backup_enabled);
        update_option('backup_schedule', $backup_schedule);
        update_option('backup_time', $backup_time);
        update_option('notification_email', $notification_email);

        // Gerenciamento dos cron jobs
        if ($automatic_backup_enabled === 'on') {
            $this->schedule_cron_jobs();
        } else {
            wp_clear_scheduled_hook('auto_backup_event');
        }

        wp_safe_redirect(admin_url('admin.php?page=dolutech-automate-backup&status=saved'));
        exit;
    }

    private function schedule_cron_jobs() {
        $schedule = sanitize_text_field(get_option('backup_schedule'));
        $backup_time = sanitize_text_field(get_option('backup_time', '02:00'));

        // Convert backup_time para timestamp
        list($hour, $minute) = explode(':', $backup_time);
        $current_time = current_time('timestamp');
        $scheduled_time = mktime($hour, $minute, 0, date('n', $current_time), date('j', $current_time), date('Y', $current_time));

        // Se a hora agendada já passou para hoje, agenda para amanhã
        if ($scheduled_time < $current_time) {
            $scheduled_time += 86400; // Adiciona um dia
        }

        wp_clear_scheduled_hook('auto_backup_event');

        if ($schedule === 'daily') {
            wp_schedule_event($scheduled_time, 'daily', 'auto_backup_event');
        } elseif ($schedule === 'weekly') {
            wp_schedule_event($scheduled_time, 'weekly', 'auto_backup_event');
        } elseif ($schedule === 'biweekly') {
            wp_schedule_event($scheduled_time, 'biweekly', 'auto_backup_event');
        } elseif ($schedule === 'monthly') {
            wp_schedule_event($scheduled_time, 'monthly', 'auto_backup_event');
        }
    }

    private function log_message($message, $level = 'INFO') {
        $log = get_option('backup_log', '');
        $log .= "[" . date("Y-m-d H:i:s") . "] [$level] " . $message . "\n";
        update_option('backup_log', $log);
    }

    /**
     * Envia notificações por e-mail baseadas no tipo e status do backup.
     *
     * @param string $message Mensagem a ser enviada no e-mail.
     * @param string $status Status do backup/restauração ('success' ou 'error').
     * @param string $type Tipo do backup ('local' ou 'ftp').
     */
    private function send_email_notification($message, $status = 'success', $type = 'local') {
        $email = sanitize_email(get_option('notification_email'));
        if ($email) {
            $subject = "Resultado do Backup do WordPress";
            $backup_type_label = ucfirst($type); // 'Local' ou 'Ftp'
            $full_message = "Olá,\n\n" . $message . "\nTipo de Backup: " . $backup_type_label . "\n\nObrigado!";

            // Adiciona status específico
            if ($status === 'success') {
                if ($type === 'ftp') {
                    $subject = "Backup Enviado com Sucesso para FTP - WordPress";
                } else {
                    $subject = "Backup Concluído com Sucesso - WordPress";
                }
            } elseif ($status === 'error') {
                $subject = "Erro no Backup do WordPress";
            }

            wp_mail($email, $subject, $full_message);
        }
    }

    public function download_backup() {
        if (!current_user_can('manage_options')) {
            wp_die('Permissão insuficiente.');
        }

        check_admin_referer('dolutech_backup_nonce_action', 'dolutech_backup_nonce');

        $backup_file = isset($_POST['backup_file']) ? basename($_POST['backup_file']) : '';
        $file_path = $this->backup_dir . '/' . $backup_file;

        if (empty($backup_file) || !file_exists($file_path)) {
            wp_die('Arquivo não encontrado.');
        }

        // Forçar o download do arquivo
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . esc_attr($backup_file) . '"');
        header('Content-Length: ' . filesize($file_path));
        readfile($file_path);
        exit;
    }

    public function delete_backup() {
        if (!current_user_can('manage_options')) {
            wp_die('Permissão insuficiente.');
        }

        check_admin_referer('dolutech_backup_nonce_action', 'dolutech_backup_nonce');

        $backup_file = isset($_POST['backup_file']) ? basename($_POST['backup_file']) : '';
        $file_path = $this->backup_dir . '/' . $backup_file;

        if (empty($backup_file) || !file_exists($file_path)) {
            wp_die('Arquivo não encontrado.');
        }

        if (unlink($file_path)) {
            wp_safe_redirect(admin_url('admin.php?page=dolutech-automate-backup&status=deleted'));
            exit;
        } else {
            wp_die('Erro ao excluir o arquivo.');
        }
    }

    public function clear_log() {
        if (!current_user_can('manage_options')) {
            wp_die('Permissão insuficiente.');
        }

        check_admin_referer('dolutech_backup_nonce_action', 'dolutech_backup_nonce');

        update_option('backup_log', '');
        wp_safe_redirect(admin_url('admin.php?page=dolutech-automate-backup&status=log_cleared'));
        exit;
    }

    // Função para restaurar backup local
    public function restore_backup() {
        if (!current_user_can('manage_options')) {
            wp_die('Permissão insuficiente.');
        }

        // Verifica o nonce
        check_admin_referer('dolutech_backup_nonce_action', 'dolutech_backup_nonce');

        $backup_file = isset($_POST['backup_file']) ? basename($_POST['backup_file']) : '';
        $file_path = $this->backup_dir . '/' . $backup_file;

        if (empty($backup_file) || !file_exists($file_path)) {
            if (wp_doing_ajax()) {
                wp_send_json_error(['message' => 'Arquivo de backup não encontrado.']);
            } else {
                wp_die('Arquivo de backup não encontrado.');
            }
        }

        // Confirmação adicional
        if (!isset($_POST['confirm_restore']) || $_POST['confirm_restore'] !== 'yes') {
            if (wp_doing_ajax()) {
                wp_send_json_error(['message' => 'Confirmação de restauração não recebida.']);
            } else {
                wp_die('Confirmação de restauração não recebida.');
            }
        }

        if (wp_doing_ajax()) {
            // Iniciar a restauração em segundo plano
            $this->set_restore_progress(0);
            wp_schedule_single_event(time(), 'dolutech_background_restore', [$file_path]);

            // Enviar e-mail informando que a restauração foi iniciada
            $this->send_email_notification("Restauração iniciada.", 'success');

            // Retornar resposta JSON para AJAX
            wp_send_json_success(['message' => 'Restauração iniciada. Acompanhe o progresso abaixo.']);
        } else {
            // Restauração síncrona para formulários padrão
            $this->log_message("Iniciando restauração do backup {$backup_file}...");

            // Extrair o backup
            $zip = new ZipArchive;
            if ($zip->open($file_path) === TRUE) {
                // Extrai para a raiz do WordPress
                $zip->extractTo(ABSPATH);
                $zip->close();
                $this->log_message("Arquivos restaurados com sucesso.");

                // Cria ou sobrescreve o arquivo .htaccess na pasta 'database' para segurança
                $htaccess_file = ABSPATH . 'database/.htaccess';
                $htaccess_content = "Deny from all\n";
                file_put_contents($htaccess_file, $htaccess_content);

                // Procurar pelo arquivo de banco de dados na pasta 'database'
                $sql_file = '';
                $extracted_files = glob(ABSPATH . 'database/database-*.sql');
                if ($extracted_files) {
                    $sql_file = $extracted_files[0];
                }

                if ($sql_file && file_exists($sql_file)) {
                    $this->restore_database($sql_file);
                    unlink($sql_file); // Remove o arquivo .sql após a restauração
                    $this->log_message("Banco de dados restaurado com sucesso.");
                } else {
                    $this->log_message("Arquivo de backup do banco de dados não encontrado após a extração.", 'ERROR');
                    $this->send_email_notification("Erro: Arquivo de backup do banco de dados não encontrado após a extração.", 'error');
                }

                // Remove o arquivo ZIP após a extração
                if (unlink($file_path)) {
                    $this->log_message("Arquivo de backup ZIP removido após restauração.");
                } else {
                    $this->log_message("Erro ao remover o arquivo de backup ZIP {$file_path} após restauração.", 'ERROR');
                    $this->send_email_notification("Erro: Falha ao remover o arquivo de backup ZIP após restauração.", 'error');
                }
            } else {
                $this->log_message("Erro ao abrir o arquivo ZIP para restauração.", 'ERROR');
                $this->send_email_notification("Erro: Falha ao abrir o arquivo ZIP para restauração.", 'error');
                wp_die('Erro ao abrir o arquivo ZIP.');
            }

            $this->log_message("Restauração concluída.");
            wp_safe_redirect(admin_url('admin.php?page=dolutech-automate-backup&status=restored'));
            exit;
        }
    }

    // Função auxiliar para dividir o arquivo SQL corretamente
    private function split_sql($sql) {
        $delimiter = ';';
        $output = [];
        $token = '';
        $in_string = false;
        $string_char = '';

        $len = strlen($sql);
        for ($i = 0; $i < $len; $i++) {
            $char = $sql[$i];
            $next_char = ($i < $len -1) ? $sql[$i+1] : '';

            if ($in_string) {
                if ($char === $string_char) {
                    if ($sql[$i-1] !== '\\') { // Não está escapado
                        $in_string = false;
                    }
                }
            } else {
                if ($char === '"' || $char === "'") {
                    $in_string = true;
                    $string_char = $char;
                }

                // Ignorar comentários SQL
                if ($char === '-' && $next_char === '-') {
                    // Pular até o final da linha
                    while ($i < $len && $sql[$i] !== "\n") {
                        $i++;
                    }
                    continue;
                }

                if ($char === '#') {
                    // Pular até o final da linha
                    while ($i < $len && $sql[$i] !== "\n") {
                        $i++;
                    }
                    continue;
                }

                if ($char === '/' && $next_char === '*') {
                    // Pular até o final do comentário
                    $i += 2;
                    while ($i < $len && !($sql[$i] === '*' && $sql[$i+1] === '/')) {
                        $i++;
                    }
                    $i += 1; // Pular a '/'
                    continue;
                }

                if ($char === $delimiter) {
                    $output[] = $token;
                    $token = '';
                    continue;
                }
            }

            $token .= $char;
        }

        if (!empty($token)) {
            $output[] = $token;
        }

        return $output;
    }

    // Função para restaurar o banco de dados com SQL correto
    private function restore_database($file) {
        global $wpdb;

        $sql = file_get_contents($file);
        if ($sql === false) {
            $this->log_message("Erro ao ler o arquivo SQL para restauração.", 'ERROR');
            return;
        }

        // Desativar restrições de chaves estrangeiras
        $wpdb->query('SET FOREIGN_KEY_CHECKS=0;');

        // Dividir o SQL em instruções individuais
        $queries = $this->split_sql($sql);

        foreach ($queries as $query) {
            $query = trim($query);
            if (!empty($query)) {
                // Verifica se a consulta é CREATE TABLE para adicionar DROP TABLE IF EXISTS
                if (preg_match('/^CREATE TABLE `([^`]+)`/i', $query, $matches)) {
                    $table_name = $matches[1];
                    $drop_table_query = "DROP TABLE IF EXISTS `{$table_name}`;";
                    $result_drop = $wpdb->query($drop_table_query);
                    if ($result_drop === false) {
                        $this->log_message("Erro ao remover a tabela {$table_name}: " . $wpdb->last_error, 'ERROR');
                        continue; // Pular para a próxima consulta
                    }
                }

                $result = $wpdb->query($query);
                if ($result === false) {
                    $this->log_message("Erro na consulta SQL: " . $wpdb->last_error . " - Consulta: {$query}", 'ERROR');
                } else {
                    // Atualiza o progresso da restauração
                    $current_progress = get_option('restore_progress', 0);
                    $this->set_restore_progress($current_progress + 1); // Incrementa o progresso
                }
            }
        }

        // Reativar restrições de chaves estrangeiras
        $wpdb->query('SET FOREIGN_KEY_CHECKS=1;');
    }

    // Função para restaurar backup por upload
    public function upload_restore_backup() {
        if (!current_user_can('manage_options')) {
            wp_die('Permissão insuficiente.');
        }

        check_admin_referer('dolutech_backup_nonce_action', 'dolutech_backup_nonce');

        if (!isset($_FILES['backup_file_upload']) || $_FILES['backup_file_upload']['error'] !== UPLOAD_ERR_OK) {
            wp_die('Erro ao fazer upload do arquivo.');
        }

        $uploaded_file = $_FILES['backup_file_upload'];

        // Verificar se o arquivo é um .zip
        $filetype = wp_check_filetype($uploaded_file['name']);
        if ($filetype['ext'] !== 'zip') {
            wp_die('Por favor, faça upload de um arquivo .zip válido.');
        }

        // Mover o arquivo para o diretório de backups
        $destination = $this->backup_dir . '/' . basename($uploaded_file['name']);
        if (!move_uploaded_file($uploaded_file['tmp_name'], $destination)) {
            wp_die('Erro ao mover o arquivo de backup.');
        }

        // Iniciar o processo de restauração em segundo plano
        $this->set_restore_progress(0);
        wp_schedule_single_event(time(), 'dolutech_background_restore', [$destination]);

        // Enviar e-mail informando que a restauração foi iniciada
        $this->send_email_notification("Restauração via upload iniciada.", 'success');

        wp_safe_redirect(admin_url('admin.php?page=dolutech-automate-backup&status=restore_started'));
        exit;
    }

    // Ação para realizar a restauração em segundo plano
    public function perform_restore($file_path) {
        if (!file_exists($file_path)) {
            $this->log_message("Erro: O arquivo de backup ZIP {$file_path} não existe.", 'ERROR');
            $this->send_email_notification("Erro: O arquivo de backup ZIP {$file_path} não existe.", 'error');
            return;
        }

        $backup_file = basename($file_path);
        $this->log_message("Iniciando restauração do backup {$backup_file}...");

        // Extrair o backup
        $zip = new ZipArchive;
        if ($zip->open($file_path) === TRUE) {
            // Extrai para a raiz do WordPress
            $zip->extractTo(ABSPATH);
            $zip->close();
            $this->log_message("Arquivos restaurados com sucesso.");

            // Cria ou sobrescreve o arquivo .htaccess na pasta 'database' para segurança
            $htaccess_file = ABSPATH . 'database/.htaccess';
            $htaccess_content = "Deny from all\n";
            file_put_contents($htaccess_file, $htaccess_content);

            // Procurar pelo arquivo de banco de dados na pasta 'database'
            $sql_file = '';
            $extracted_files = glob(ABSPATH . 'database/database-*.sql');
            if ($extracted_files) {
                $sql_file = $extracted_files[0];
            }

            if ($sql_file && file_exists($sql_file)) {
                $this->restore_database($sql_file);
                unlink($sql_file); // Remove o arquivo .sql após a restauração
                $this->log_message("Banco de dados restaurado com sucesso.");
            } else {
                $this->log_message("Arquivo de backup do banco de dados não encontrado após a extração.", 'ERROR');
                $this->send_email_notification("Erro: Arquivo de backup do banco de dados não encontrado após a extração.", 'error');
            }

            // Remove o arquivo ZIP após a extração
            if (unlink($file_path)) {
                $this->log_message("Arquivo de backup ZIP removido após restauração.");
            } else {
                $this->log_message("Erro ao remover o arquivo de backup ZIP {$file_path} após restauração.", 'ERROR');
                $this->send_email_notification("Erro: Falha ao remover o arquivo de backup ZIP após restauração.", 'error');
            }
        } else {
            $this->log_message("Erro ao abrir o arquivo ZIP para restauração.", 'ERROR');
            $this->send_email_notification("Erro: Falha ao abrir o arquivo ZIP para restauração.", 'error');
        }

        $this->log_message("Restauração concluída.");
    }

    // Registro de intervalos adicionais de agendamento
    public function custom_cron_schedules($schedules) {
        $schedules['biweekly'] = ['interval' => 1209600, 'display' => __('Quinzenal')];
        $schedules['monthly'] = ['interval' => 2592000, 'display' => __('Mensal')];
        return $schedules;
    }
}

new Dolutech_Automate_Backup();
?>
