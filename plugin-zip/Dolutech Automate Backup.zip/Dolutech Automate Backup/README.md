# Dolutech Automate Backup

**Contributors:** lucas.catao  
**Tags:** backup, FTP, WordPress, segurança, restauração  
**Requires at least:** 6.5  
**Tested up to:** 6.5  
**Requires PHP:** 7.4  
**License:** GPL-2.0+  
**License URI:** http://www.gnu.org/licenses/gpl-2.0.txt  

## Descrição

O **Dolutech Automate Backup** é um plugin de backup completo para WordPress, oferecendo uma maneira simples e segura de proteger seu conteúdo. Com suporte para backup local e FTP, você pode armazenar seus arquivos e dados em locais seguros. Ele inclui uma opção de restauração completa que permite a recuperação fácil dos dados. Configure backups automáticos e receba notificações para garantir que seu site esteja sempre seguro.

## Funcionalidades

- **Backup Completo:** Cria backups de todos os arquivos do site e banco de dados.
- **Armazenamento Local e FTP:** Armazene backups localmente ou envie para um servidor FTP.
- **Agendamento Automático:** Defina backups diários, semanais, quinzenais ou mensais.
- **Restauração Completa:** Restaure arquivos e banco de dados diretamente pelo painel.
- **Logs Detalhados e Barra de Progresso:** Monitore o status de cada operação de backup e restauração.
- **Notificações por E-mail:** Receba e-mails sobre o status dos backups e restauras.

## Instalação

1. **Upload do Plugin:** Envie a pasta `dolutech-automate-backup` para o diretório `/wp-content/plugins/`.
2. **Ativação:** No painel do WordPress, vá em **Plugins > Plugins Instalados** e ative o **Dolutech Automate Backup**.
3. **Configuração:** Acesse **Dolutech Backup** no menu do painel para configurar e iniciar seus backups.

## Configuração

1. Acesse **Dolutech Backup** no painel de administração do WordPress.
2. Configure o **Tipo de Backup** (local ou FTP).
3. Para backups FTP, insira as informações do servidor (endereço, usuário, senha e caminho de armazenamento).
4. Defina a **Frequência** e **Horário** para os backups automáticos.
5. Insira um **e-mail de notificação** para alertas automáticos.
6. Clique em **Salvar Configurações** para confirmar.

## Como Usar

### Fazer Backup Manual
1. Acesse **Dolutech Backup**.
2. Clique em **Fazer Backup Manual** para iniciar imediatamente.
3. Acompanhe o progresso na barra de progresso exibida.

### Restaurar Backup
1. Na seção **Backups Locais Disponíveis**, selecione um backup e clique em **Restaurar**.
2. Para restaurar via upload, use a seção **Restaurar Backup por Upload** e selecione um arquivo `.zip`.

## Perguntas Frequentes

### 1. Quais são os requisitos para usar este plugin?
   - PHP 7.4 ou superior.
   - WordPress 6.5 ou superior.

### 2. Onde os backups são armazenados?
   - Você pode armazenar backups localmente no servidor ou enviá-los para um servidor FTP.

### 3. Como configuro as notificações por e-mail?
   - Na página de configurações do plugin, insira o e-mail que deseja receber notificações sobre o status dos backups e restaurações.

### 4. Como agendo backups automáticos?
   - Na seção **Configurações de Backup Automático**, defina a frequência (diário, semanal, quinzenal ou mensal) e o horário desejado.

## Screenshots

1. **Página de Configuração do Plugin**  
   ![Página de Configuração do Plugin](screenshot-1.png)

2. **Lista de Backups Disponíveis**  
   ![Lista de Backups Disponíveis](screenshot-2.png)

3. **Configuração de Backup Automático e Notificações**  
   ![Configuração de Backup Automático e Notificações](screenshot-3.png)

## Notas de Desenvolvimento

- **Versão Atual:** 0.1.0
- **Changelog:**
  - **0.1.0** – Lançamento inicial com suporte a backup local e FTP, restauração, agendamento de backups automáticos e logs.

## Licença

Este plugin é distribuído sob a licença GPL-2.0+. Mais informações estão disponíveis em [http://www.gnu.org/licenses/gpl-2.0.txt](http://www.gnu.org/licenses/gpl-2.0.txt).

---

**Desenvolvido por Lucas Catão de Moraes** | [Dolutech](https://dolutech.com)
