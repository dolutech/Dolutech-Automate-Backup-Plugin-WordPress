// script.js

jQuery(document).ready(function($) {

    /**
     * Manipulador para o botão de Backup Manual
     * Inicia o processo de backup via AJAX e monitora o progresso.
     */
    $('#backup-button').on('click', function(e) {
        e.preventDefault(); // Previne o comportamento padrão do formulário

        var progressBar = $('#backup-progress-bar');
        progressBar.show(); // Exibe a barra de progresso
        $('#backup-progress-bar .progress').css('width', '0%'); // Reseta a largura da barra
        $('.dolutech-backup-message').remove(); // Remove mensagens anteriores

        // Adiciona a mensagem de backup em andamento
        $('<div class="dolutech-backup-message" style="margin-top:10px;">Backup sendo efetuado...</div>').insertAfter('#backup-progress-bar');

        // Inicia o backup via AJAX
        $.ajax({
            url: dolutechBackup.ajax_url, // URL do admin-ajax.php
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'manual_backup', // Nome da ação registrada no PHP
                nonce: dolutechBackup.nonce // Nonce para verificação de segurança
            },
            success: function(response) {
                if (response.success) {
                    // Inicia a verificação do progresso do backup
                    checkBackupProgress();
                } else {
                    // Exibe alerta em caso de erro ao iniciar o backup
                    alert('Erro ao iniciar o backup: ' + (response.data.message || ''));
                    progressBar.hide(); // Esconde a barra de progresso
                    $('.dolutech-backup-message').remove();
                }
            },
            error: function() {
                // Exibe alerta em caso de falha na requisição AJAX
                alert('Erro ao iniciar o backup.');
                progressBar.hide(); // Esconde a barra de progresso
                $('.dolutech-backup-message').remove();
            }
        });
    });

    /**
     * Função para verificar o progresso do backup
     * Faz requisições periódicas para obter o progresso atual e atualiza a interface.
     */
    function checkBackupProgress() {
        $.ajax({
            url: dolutechBackup.ajax_url, // URL do admin-ajax.php
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'get_backup_progress', // Ação para obter o progresso
                nonce: dolutechBackup.nonce // Nonce para verificação de segurança
            },
            success: function(response) {
                if (response.success) {
                    var progress = parseInt(response.data.progress, 10); // Obtém o progresso atual

                    // Atualiza a barra de progresso
                    $('#backup-progress-bar .progress').css('width', progress + '%');

                    if (progress < 100) {
                        setTimeout(checkBackupProgress, 2000); // Verifica novamente após 2 segundos
                    } else {
                        $('#backup-progress-bar').fadeOut(); // Esconde a barra de progresso
                        // Atualiza a mensagem para informar que o backup foi concluído
                        $('.dolutech-backup-message').text('Backup concluído com sucesso.');
                        // Recarrega a página após 2 segundos para refletir os novos backups disponíveis
                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                    }
                } else {
                    // Exibe alerta em caso de erro ao obter o progresso do backup
                    alert('Erro ao obter o progresso do backup: ' + (response.data.message || ''));
                    $('#backup-progress-bar').hide(); // Esconde a barra de progresso
                    $('.dolutech-backup-message').remove();
                }
            },
            error: function() {
                // Em caso de erro na requisição, tenta novamente após 2 segundos
                setTimeout(checkBackupProgress, 2000);
            }
        });
    }

    /**
     * Manipulador para os formulários de Restauração via Formulário
     * Detecta se a ação é de restauração e envia via AJAX.
     */
    $('form').on('submit', function(e) {
        var form = $(this);
        var action = form.find('input[name="action"]').val(); // Obtém o valor da ação do formulário

        if (action === 'restore_backup') {
            e.preventDefault(); // Previne o comportamento padrão do formulário

            var progressBar = $('#backup-progress-bar');
            progressBar.show(); // Exibe a barra de progresso
            $('#backup-progress-bar .progress').css('width', '0%'); // Reseta a largura da barra
            $('.dolutech-backup-message').remove(); // Remove mensagens anteriores

            // Adiciona a mensagem de restauração em andamento
            $('<div class="dolutech-backup-message" style="margin-top:10px;">Backup sendo restaurado...</div>').insertAfter('#backup-progress-bar');

            // Coleta os dados do formulário
            var formData = {
                action: 'restore_backup',
                backup_file: form.find('input[name="backup_file"]').val(),
                confirm_restore: form.find('input[name="confirm_restore"]').val(),
                nonce: dolutechBackup.nonce
            };

            // Inicia a restauração via AJAX
            $.ajax({
                url: dolutechBackup.ajax_url, // URL do admin-ajax.php
                type: 'POST',
                dataType: 'json',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        // Inicia a verificação do progresso da restauração
                        checkRestoreProgress();
                    } else {
                        // Exibe alerta em caso de erro ao iniciar a restauração
                        alert('Erro ao iniciar a restauração: ' + (response.data.message || ''));
                        progressBar.hide(); // Esconde a barra de progresso
                        $('.dolutech-backup-message').remove();
                    }
                },
                error: function() {
                    // Exibe alerta em caso de falha na requisição AJAX
                    alert('Erro ao iniciar a restauração.');
                    progressBar.hide(); // Esconde a barra de progresso
                    $('.dolutech-backup-message').remove();
                }
            });
        } else if (action === 'upload_restore_backup') {
            e.preventDefault(); // Previne o comportamento padrão do formulário

            var formElement = form[0];
            var formData = new FormData(formElement); // Cria um FormData para enviar o arquivo

            var progressBar = $('#backup-progress-bar');
            progressBar.show(); // Exibe a barra de progresso
            $('#backup-progress-bar .progress').css('width', '0%'); // Reseta a largura da barra
            $('.dolutech-backup-message').remove(); // Remove mensagens anteriores

            // Adiciona a mensagem de restauração em andamento
            $('<div class="dolutech-backup-message" style="margin-top:10px;">Backup sendo restaurado...</div>').insertAfter('#backup-progress-bar');

            // Inicia a restauração via AJAX com upload
            $.ajax({
                url: dolutechBackup.ajax_url, // URL do admin-ajax.php
                type: 'POST',
                dataType: 'json',
                data: formData, // Envia os dados do formulário, incluindo o arquivo
                processData: false, // Necessário para enviar FormData
                contentType: false, // Necessário para enviar FormData
                success: function(response) {
                    if (response.success) {
                        // Inicia a verificação do progresso da restauração
                        checkRestoreProgress();
                    } else {
                        // Exibe alerta em caso de erro ao iniciar a restauração
                        alert('Erro ao iniciar a restauração: ' + (response.data.message || ''));
                        progressBar.hide(); // Esconde a barra de progresso
                        $('.dolutech-backup-message').remove();
                    }
                },
                error: function() {
                    // Exibe alerta em caso de falha na requisição AJAX
                    alert('Erro ao iniciar a restauração.');
                    progressBar.hide(); // Esconde a barra de progresso
                    $('.dolutech-backup-message').remove();
                }
            });
        }
    });

    /**
     * Função para verificar o progresso da restauração
     * Faz requisições periódicas para obter o progresso atual e atualiza a interface.
     */
    function checkRestoreProgress() {
        $.ajax({
            url: dolutechBackup.ajax_url, // URL do admin-ajax.php
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'get_restore_progress', // Ação para obter o progresso da restauração
                nonce: dolutechBackup.nonce // Nonce para verificação de segurança
            },
            success: function(response) {
                if (response.success) {
                    var progress = parseInt(response.data.progress, 10); // Obtém o progresso atual

                    // Atualiza a barra de progresso
                    $('#backup-progress-bar .progress').css('width', progress + '%');

                    if (progress < 100) {
                        setTimeout(checkRestoreProgress, 2000); // Verifica novamente após 2 segundos
                    } else {
                        $('#backup-progress-bar').fadeOut(); // Esconde a barra de progresso
                        // Atualiza a mensagem para informar que a restauração foi concluída
                        $('.dolutech-backup-message').text('Restauração concluída com sucesso.');
                        // Recarrega a página após 2 segundos para refletir as mudanças
                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                    }
                } else {
                    // Exibe alerta em caso de erro ao obter o progresso da restauração
                    alert('Erro ao obter o progresso da restauração: ' + (response.data.message || ''));
                    $('#backup-progress-bar').hide(); // Esconde a barra de progresso
                    $('.dolutech-backup-message').remove();
                }
            },
            error: function() {
                // Em caso de erro na requisição, tenta novamente após 2 segundos
                setTimeout(checkRestoreProgress, 2000);
            }
        });
    }

});
